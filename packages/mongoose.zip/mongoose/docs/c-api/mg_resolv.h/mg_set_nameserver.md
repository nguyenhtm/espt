---
title: "mg_set_nameserver()"
decl_name: "mg_set_nameserver"
symbol_kind: "func"
signature: |
  void mg_set_nameserver(struct mg_mgr *mgr, const char *nameserver);
---

Set default DNS server 

