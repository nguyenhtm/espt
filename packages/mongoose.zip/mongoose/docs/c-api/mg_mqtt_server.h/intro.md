---
title: "MQTT Server API reference"
symbol_kind: "intro"
decl_name: "mg_mqtt_server.h"
items:
  - { name: LIST_ENTRY.md }
  - { name: struct_mg_mqtt_broker.md }
  - { name: struct_mg_mqtt_session.md }
---



