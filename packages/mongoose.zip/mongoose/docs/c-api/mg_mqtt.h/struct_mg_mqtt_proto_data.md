---
title: "struct mg_mqtt_proto_data"
decl_name: "struct mg_mqtt_proto_data"
symbol_kind: "struct"
signature: |
  struct mg_mqtt_proto_data {
    uint16_t keep_alive;
    double last_control_time;
  };
---

mg_mqtt_proto_data should be in header to allow external access to it 

